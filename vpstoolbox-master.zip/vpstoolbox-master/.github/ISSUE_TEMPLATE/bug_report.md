---
name: 🐛 Bug 报告
about: Create a report to help us improve
title: ''
labels: bug
assignees: johnrosen1

---

<!--
请确保已阅读 [文档](https://github.com/johnrosen1/vpstoolbox/blob/master/docs/README_zh_cn.md) 内相关部分，并按照模版提供信息，否则 issue 将被立即关闭。

由于部分伺服器厂商限制CPU缘故，项目可能安装失败，该问题不是VPSTOOLBOX 所致，请勿提交 issue(严禁提交任何Vultr导致的错误的issue)。
-->

- 预期是什么

- 实际发生了什么

- 你做了什么

| Env                | Value         |
| ------------------ | ------------- |
| OS                 |               |

- 额外信息（日志、报错等）
