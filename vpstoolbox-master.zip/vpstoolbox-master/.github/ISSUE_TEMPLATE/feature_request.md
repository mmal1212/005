---
name: 🍭 功能需求
about: 提交新的功能需求
title: ''
labels: ''
assignees: ''

---

<!--
请确保 [文档](https://github.com/johnrosen1/vpstoolbox/blob/master/docs/README_zh_cn.md)中没有相关内容，并按照模版提供信息
否则 issue 将被立即关闭
-->

### 这是一个什么样的功能？

### 这个功能可以解决什么问题？

### 额外描述

### 你觉得这个功能是否应该作为默认安装选项出现?
